import joblib
import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler

scaler = joblib.load(open('scaler.pkl','rb'))
model = joblib.load('model.h5')

def predict(df): 
 
    df = df[['date_time', 'T_data_1_1', 'T_data_1_2', 'T_data_1_3', 'T_data_2_1',
       'T_data_2_2', 'T_data_2_3', 'T_data_3_1', 'T_data_3_2', 'T_data_3_3',
       'T_data_4_1', 'T_data_4_2', 'T_data_4_3', 'T_data_5_1', 'T_data_5_2',
       'T_data_5_3', 'H_data', 'AH_data']]
    df.drop(["date_time"], axis = 1, inplace = True)
    df_scaled = pd.DataFrame(scaler.transform(df), columns = df.columns)
    predictions = model.predict(df_scaled)
    output = predictions.astype(int)
    output = output.tolist()   
    return output

